function openForm(eventName) {
  document.getElementById('eventName').value = eventName;
  document.getElementById('bookingModal').style.display = 'flex';
  document.getElementById('formStep').style.display = 'block';
  document.getElementById('paymentStep').style.display = 'none';
}

function closeForm() {
  document.getElementById('bookingModal').style.display = 'none';
}

function showPayment() {
  const bookingAmount = parseFloat(document.getElementById('amount').value);
  if (!bookingAmount || bookingAmount <= 0) {
    alert("Please enter a valid booking amount.");
    return;
  }

  document.getElementById('formStep').style.display = 'none';
  document.getElementById('paymentStep').style.display = 'block';

  const appFee = (bookingAmount * 0.01).toFixed(2);
  const totalAmount = (bookingAmount + parseFloat(appFee)).toFixed(2);

  document.getElementById('paymentInfo').innerHTML = `
    <p>Booking Amount: $${bookingAmount}</p>
    <p>App Fee (1%): $${appFee}</p>
    <p>Total Amount: $${totalAmount}</p>
  `;
}

function processPayment(method) {
  alert(`Payment successful using ${method}!`);
  closeForm();
}